-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 16, 2024 at 11:58 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop_on`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `email`, `password`) VALUES
(1, 'hussnain12@gmail.com', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `clothes`
--

CREATE TABLE `clothes` (
  `company_id` int(255) NOT NULL,
  `clothes_id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `price` int(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `detail_one` varchar(255) NOT NULL,
  `detail_two` varchar(255) NOT NULL,
  `detail_three` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `shirt_fabric` varchar(255) NOT NULL,
  `trouser_fabric` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `time_stamp` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `clothes`
--

INSERT INTO `clothes` (`company_id`, `clothes_id`, `name`, `code`, `price`, `description`, `detail_one`, `detail_two`, `detail_three`, `color`, `gender`, `shirt_fabric`, `trouser_fabric`, `logo`, `time_stamp`) VALUES
(1, 1, 'Blue Styling Kurta KR-STY24-027', ' M-AP-24-398040 -P', 3276, 'Adorn the latest trends in traditional wear by Ideas Man.', 'Blended', 'Regular Fit', 'Model Specs: The model is 6ft 2in and wearing size Medium', 'Blue', 'feMale', 'Blended', 'Blended', '66881c22a98b3.jpg', '2024-07-12 16:08:17.369891'),
(1, 2, 'Grey Embroidered Suit SK-E24-016', 'M-AP-24-390514 -P', 7380, 'Adorn the latest trends in traditional wear by Ideas Man.', '100% Cotton', 'Regular Fit', 'Model Specs: The model is 6 ft and wearing size Medium', 'Grey', 'Male', 'Cotton', 'Cotton', '66882028ab618.jpg', '2024-07-05 16:32:40.704037'),
(1, 3, 'Charcoal Basic Suit SK-P24-026', 'M-AP-24-396246 -P', 4918, 'Adorn the latest trends in traditional wear by Ideas Man.', 'Blended', 'Regular Fit', 'Model Specs: The model is 6 ft and wearing size Medium', 'Charcoal', 'Male', 'Blended', 'Blended', '668bf2e1b4d8a.jpg', '2024-07-08 14:08:33.742856'),
(1, 4, 'Umber Basic Suit SK-PSD24-003', ' M-AP-24-397892 -P', 9843, 'Adorn the latest trends in traditional wear by Ideas Man.', 'Blended', 'Regular Fit', 'Model Specs: The model is 6 ft and wearing size Medium', 'Umber', 'Male', 'Blended', 'Blended', '668bf33e5b77b.jpg', '2024-07-08 14:10:06.376529');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `company_id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `company_type` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `time_stamp` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`company_id`, `name`, `email`, `password`, `contact`, `country`, `city`, `company_name`, `company_type`, `logo`, `time_stamp`) VALUES
(1, 'Hussnain ', 'husnainsulehri786@gmail.com', '12345', '0311123456', 'Pakistan', 'Lahore', 'Gul Ahmed', 'Menware', '668810c6478bc.jpg', '2024-07-05 15:27:02.293993'),
(2, 'Sana ', 'sanasafinaz6@gmail.com', '12345', '0301345345', 'Pakistan', 'Karachi', 'Sana Safinaz', 'Women Clothes', '668820ded4cb7.jpg', '2024-07-05 16:35:42.873872');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `time_stamp` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `clothes`
--
ALTER TABLE `clothes`
  ADD PRIMARY KEY (`clothes_id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`company_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `clothes`
--
ALTER TABLE `clothes`
  MODIFY `clothes_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `company_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(255) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
