<?php

session_start();
    
    if (isset($_SESSION['company_id'])) {
        header("Location:index.php");
         exit();
    }

?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        background-color:#000000;
            background-size: cover;
            background-position: center;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            width: 400px;
            padding: 20px;
            border-radius: 5px;
/*            background-color: rgba(255, 255, 255, 0.8); /* Semi-transparent background */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        label {
            display: block;
            margin-bottom: 10px;
            color: grey;
        }
        input[type="text"], input[type="password"] {
            width: calc(101% - 30px);
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 3px;
            background-color:black;
            color: grey;

        }
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            border: none;
            border-radius: 3px;
           background-color: #4CAF50;
            color: white;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        .password-container {
            position: relative;
        }
        .toggle-password {
            position: absolute;
            top: 50%;
            right: 10px;
            transform: translateY(-50%);
            cursor: pointer;
            color: #aaa;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
         <div class="col-lg-12  col-md-12 col-xl-12 col-sm-12 col-xs-12 ">
        <h2>Logi</h2>
        <form id="loginForm" onsubmit="return validateForm()">
            <label for="email">Username</label>
            <input type="text" id="username" name="email" placeholder="Enter your email">

            <label for="password" style="position: relative;">Password
                <div class="password-container">
                    <input type="password" id="password" name="password" placeholder="Enter your password">
                    <span class="toggle-password" onclick="togglePasswordVisibility()">
                        <i class="fas fa-eye"></i>
                    </span>
                </div>
            </label>

            <input type="submit" value="Submit">
        </form>
    </div>
   </div>
</div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
    <script>
        function validateForm() {
            var username = document.getElementById("username").value;
            var password = document.getElementById("password").value;

            // Simple validation
            if (username.trim() === '' || password.trim() === '') {
                alert("Please enter both username and password.");
                return false;
            }

            // You can add more complex validation logic here if needed

            return true; // Submit the form
        }

        function togglePasswordVisibility() {
            var passwordInput = document.getElementById("password");
            var toggleBtn = document.querySelector(".toggle-password");

            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                toggleBtn.innerHTML = '<i class="fas fa-eye-slash"></i>';
            } else {
                passwordInput.type = "password";
                toggleBtn.innerHTML = '<i class="fas fa-eye"></i>';
            }
        }
    </script>
</body>
</html>

