<?php
session_start();

$response = ['success' => false];

if (isset($_POST['product_id']) && isset($_POST['quantity'])) {
    $product_id = $_POST['product_id'];
    $quantity = (int)$_POST['quantity'];

    foreach ($_SESSION['cart'] as $key => $product) {
        if ($product['product_id'] == $product_id) {
            // Update the quantity in the session
            $_SESSION['cart'][$key]['quantity'] = $quantity;

            // Calculate the new product total
            $product_total = $quantity * $product['product_price'];

            // Calculate the new cart total
            $cart_total = 0;
            foreach ($_SESSION['cart'] as $item) {
                $cart_total += $item['quantity'] * $item['product_price'];
            }

            $response['success'] = true;
            $response['product_total'] = number_format($product_total, 2);
            $response['cart_total'] = number_format($cart_total, 2);

            break;
        }
    }
}

header('Content-Type: application/json');
echo json_encode($response);
