<?php
session_start();
require_once ("database.php");

if (isset($_POST)) {
	
	// call data from client page
	$email= mysqli_real_escape_string($conn,$_POST['email']);
	$password= mysqli_real_escape_string($conn,$_POST['password']);

	// apply condition to make/check data unique

	$sql="SELECT company_id,name,email,password,company_name FROM company WHERE email = '$email' AND password = '$password'";
	$result=$conn->query($sql);

	// whatshappen if above condition true or false

	if ($result->num_rows > 0) {
		$row=$result->fetch_assoc();
		$_SESSION['company_id']=$row['company_id'];
		$_SESSION['name']=$row['name'];
		$_SESSION['company_name']=$row['company_name'];
		header("Location:company/index.php");
		exit();
	}
	else{
		echo "Email or Passoword not found";
	}
}
else{
		echo "Error-2";
	}
?>