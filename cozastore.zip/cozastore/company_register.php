<?php
session_start();

// if (empty($_SESSION['company_id'])) {
//     header("Location:index.php");
//     exit();
// }
require_once ("database.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Registration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }
        .form-container {
            background-color: #ffffff;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 30px;
            margin: 30px auto;
            max-width: 800px;
        }
        .form-heading {
            font-size: 36px;
            font-weight: 700;
            text-align: center;
            color: #343a40;
            margin-bottom: 30px;
        }
        .form-control {
            border-radius: 8px;
            border: 1px solid #ced4da;
        }
        .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 0 0.2rem rgba(38, 143, 255, 0.25);
        }
        .btn-custom {
            background-color: #007bff;
            color: #ffffff;
            border-radius: 8px;
            border: none;
        }
        .btn-custom:hover {
            background-color: #0056b3;
        }
        .alert {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <div class="form-heading">Add Your Company Details</div>
            <form action="com_reg_ser.php" method="POST" enctype="multipart/form-data">
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <input type="text" class="form-control" placeholder="Name" name="name" required>
                        </div>
                        <div class="mb-3">
                            <input type="email" class="form-control" placeholder="name@example.com" name="email" required>
                        </div>
                        <div class="mb-3">
                            <input type="text" class="form-control" placeholder="Country" name="country" required>
                        </div>
                        <div class="mb-3">
                            <input type="number" class="form-control" placeholder="Contact" name="contact" required>
                        </div>
                        <div class="mb-3">
                            <input type="file" class="form-control" placeholder="Choose Logo" name="image">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <input type="text" class="form-control" placeholder="Company Name" name="cmp_name" required>
                        </div>
                        <div class="mb-3">
                            <input type="password" class="form-control" placeholder="Password" name="password" required>
                        </div>
                        <div class="mb-3">
                            <input type="text" class="form-control" placeholder="City" name="city" required>
                        </div>
                        <div class="mb-3">
                            <input type="text" class="form-control" placeholder="Company Type" name="type" required>
                        </div>
                        <div class="d-grid">
                            <button class="btn btn-custom" type="submit">Register</button>
                        </div>
                        <?php if (isset($_SESSION['registerError'])): ?>
                            <div class="alert alert-danger">
                                Data not stored in DB.
                            </div>
                            <?php unset($_SESSION['registerError']); ?>
                        <?php endif; ?>
                        <?php if (isset($_SESSION['uploadError'])): ?>
                            <div class="alert alert-danger">
                                <?php echo $_SESSION['uploadError']; ?>
                            </div>
                            <?php unset($_SESSION['uploadError']); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
    </div>
</body>
</html>

