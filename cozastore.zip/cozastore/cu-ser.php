<?php
session_start();
require_once("datab-ase.php"); // Ensure this file correctly connects to your MySQL database

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Validate form data
    if (empty($email) || empty($password)) {
        echo "Please fill in all fields.";
        exit();
    }

    // Check if email already exists
    $checkEmailQuery = "SELECT * FROM cu WHERE email = ?";
    $stmt = $conn->prepare($checkEmailQuery);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "Email is already registered.";
        exit();
    }

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Insert user into the database
    $insertQuery = "INSERT INTO cu (email, password) VALUES (?, ?)";
    $stmt = $conn->prepare($insertQuery);
    $stmt->bind_param("ss", $email, $hashedPassword);

    if ($stmt->execute()) {
        echo "Registration successful. Welcome!";
        header("Location:index.php");
        exit();
    } else {
        echo "Something went wrong. Please try again.";
        exit();
    }
} else {
    echo "Invalid request.";
    exit();
}
?>
