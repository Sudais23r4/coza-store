<?php
session_start();
require_once ("database.php");

$product_id = $_GET['id'];

$sql = "SELECT * FROM clothes WHERE clothes_id='$product_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $product = $result->fetch_assoc();
    $sql1 = "SELECT * FROM company WHERE company_id='$product[company_id]'";
    $result1 = $conn->query($sql1);
    $company = $result1->fetch_assoc();
} else {
    echo "Error: Product not found.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $product['name']; ?> - Product Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="path_to_your_css/main.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
        }
        .product-container {
            max-width: 1200px;
            margin: 50px auto;
            display: flex;
            flex-wrap: wrap;
        }
        .product-image {
            flex: 1;
            padding: 20px;
        }
        .product-image img {
            width: 100%;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .product-details {
            flex: 1;
            padding: 20px;
        }
        .product-details h2 {
            font-size: 2.5rem;
            color: #333;
        }
        .product-details p {
            font-size: 1.1rem;
            line-height: 1.6;
            color: #555;
        }
        .product-details .price {
            font-size: 1.8rem;
            color: #e74c3c;
            margin: 20px 0;
        }
        .product-details ul {
            list-style: none;
            padding: 0;
            margin: 20px 0;
        }
        .product-details ul li {
            margin-bottom: 10px;
            font-size: 1.1rem;
            color: #333;
        }
        .product-details button {
            background-color: #e74c3c;
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 5px;
            font-size: 1.2rem;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .product-details button:hover {
            background-color: #c0392b;
        }
        @media (max-width: 768px) {
            .product-container {
                flex-direction: column;
            }
            .product-image, .product-details {
                flex: 100%;
            }
        }
    </style>
</head>
<body>

<div class="container product-container">
    <!-- Product Image -->
    <div class="product-image">
        <img src="upload/product/<?php echo $product['logo']; ?>" alt="<?php echo $product['name']; ?>">
    </div>

    <!-- Product Details -->
    <!-- <form action="manage-cart.php" method="POST" > -->
    <div class="product-details">
        <h2  ><?php echo $product['name']; ?></h2>
        <p><strong>Prcode:</strong> <?php echo $product['code']; ?></p>
        <p class="price"  >Price:<?php echo $product['price']; ?></p>
        <p><?php echo $product['description']; ?></p>
        <ul>
          <!--   <li><strong>Detail One:</strong> <?php echo $product['detail_one']; ?></li>
            <li><strong>Detail Two:</strong> <?php echo $product['detail_two']; ?></li>
            <li><strong>Detail Three:</strong> <?php echo $product['detail_three']; ?></li> -->
            <li><strong>Color:</strong> <?php echo $product['color']; ?></li>
            <li><strong>Gender:</strong> <?php echo $product['gender']; ?></li>
            <li><strong>Shirt Fabric:</strong> <?php echo $product['shirt_fabric']; ?></li>
            <!-- <li><strong></strong> <?php echo $product['trouser_fabric']; ?></li> -->
        </ul>
        
        <form action="manage-cart.php" method="POST">
    <input type="hidden" name="product_id" value="<?php echo $product['clothes_id']; ?>">
    <input type="hidden" name="product_name" value="<?php echo $product['name']; ?>">
    <input type="hidden" name="product_price" value="<?php echo $product['price']; ?>">
    <button type="submit" name="Add_to_Cart" class="btn btn-primary">Add to Cart</button>
</form>

    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
