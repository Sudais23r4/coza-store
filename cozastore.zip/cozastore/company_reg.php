<?php 

session_start();

  // if (empty($_SESSION['company_id']) ) {
  //      header("Location:company_reg.php");
  //    exit();
// }


?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="css/AdminLTE.min.css">
  <link rel="stylesheet" href="css/_all-skins.min.css">
  <!-- Custom -->
  <link rel="stylesheet" href="css/custom.css?v=<?php echo time(); ?>">
  <link rel="stylesheet" href="css/style2.css?v=<?php echo time(); ?>">
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
    <script src="js/java.js"></script>
    <script src="js/java2.js"></script>
  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
  <style type="text/css">
    .ml-9{
      margin-left: 70px;
/*      margin-top: 5px;*/
      box-shadow: 0 10px 10px rgba(0,0,0,.2);   
    }
    .bg-color{
      background: #0082e6;
      font-size: 20px;
    }
    .navbar-brand{
/*        font-size: 25px;*/
        font-family: montserrat;
    }
    #color{
      color: white;
      font-family: montserrat;
      margin-left: 15px;
      color: white;
      font-size: 17px;
      padding: 7px 13px;
      border-radius: 3px;
      text-transform: uppercase;
/*      background-color: gainsboro;*/
    }
    a.active,a:hover{
      background: #1b9bff;
      transition: .5s;
    }
  </style>
</head>
<body class="hold-transition sidebar-mini">
<!-- <div class="wrapper">

  <nav class="navbar navbar-expand-lg navbar-light bg-color">
      <div class="container-fluid">
        <a class="navbar-brand" href="#" style="color: white;margin-left:40px;padding: 7px 13px;">Coza Store</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse " id="navbarNav" style="margin-left:190px" >
          <ul class="navbar-nav" >
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="index.php" id="color" >Home</a>
            </li>
            <?php if(empty($_SESSION['user_id']) && empty($_SESSION['company_id'])) { ?>
            <li class="nav-item">
              <a class="nav-link" href="login.php" id="color">Login</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="sign-up.php" id="color">SignUp</a>
            </li>
            <?php } else { 

             if(isset($_SESSION['user_id'])) { 
            ?>        
            <li>
              <a href="customer/index.php">Dashboard</a>
            </li>
            <?php
               } else if(isset($_SESSION['company_id'])) { 
            ?>        
            <li>
              <a href="company/index.php">Dashboard</a>
            </li>
            <?php } ?>
            <li>
              <a href="logout.php">Logout</a>
            </li>
            <?php } ?>
          </ul>
        </div>
      </div>
      </nav> -->
          

  <!-- Content Wrapper. Contains page content -->
  
      <div class="container">
        <div class="row">
           <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12"> 
        <div  class="latest-job margin-top-20 ">
          <h1 class="text-center margin-bottom-10" style="  text-align: center; ">My Accounts</h1>
             <div class="dropdown" style="margin :20px; margin-top: 10px;">
  <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
    logout
  </a>

  <ul class="dropdown-menu" >
    <li><a class="dropdown-item" href="logout.php">logout-Company</a></li>
    <li><a class="dropdown-item" href="logout-cu.php">logout-Customer</a></li>
              </div>
        
          <div class=" latest-job ">
            <div class="small-box bg-dark padding-5" style="border-radius: 4px; box-shadow: 4px 2px;color: grey;">
              <div class="inner">
                <h3 class="textstyle" style="color:white border-radius: 4px; box-shadow: 4px 2px;color: lightgray;">Company login</h3>
              </div>
              <a href="company_login.php" class="small-box-footer" style="font-family: montserrat;font-size: 25px;background-color: white; color: black; border-radius: 4px;box-shadow: 4px 2px;color: lightgray;">
                Register <i class="fa fa-arrow-circle-right"></i>
              </a>
            </div></div>
          </div>
          <div class=" latest-job ">
            <div class="small-box bg-dark padding-5" style="border-radius: 4px; box-shadow: 4px 2px;color: grey;">
              <div class="inner">
                <h3 class="textstyle" style="color:white border-radius: 4px; box-shadow: 4px 2px;color: lightgray;">Company Registeration</h3>
              </div>
              <a href="company_register.php" class="small-box-footer" style="font-family: montserrat;font-size: 25px; background-color: white; color: black; border-radius: 4px; box-shadow: 4px 2px;color: lightgray;">
                Register <i class="fa fa-arrow-circle-right "></i>
              </a>
            </div>

            <div class=" latest-job margin-bottom-20 margin-top-20" style="text-align: center;">
              <a href="cu-rg.php">
                <button type="Submit" class="btn btn-outline-dark">Customer Account</button>
              </a>
         
        </div> 
        </div>

        
      </div>
         
 

  <!-- <footer class="main-footer" style="margin-left: 0px;margin-top: 440px;">
    <div class="text-center">
      <strong>Copyright 2023-<?php echo date('Y'); ?> <a href="#">Flip & Buy</a>.</strong> All rights
    reserved.
    </div>
  </footer> -->

  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>

</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="js/adminlte.min.js"></script>
</body>
</html>
