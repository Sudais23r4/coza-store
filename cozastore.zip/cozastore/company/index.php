<?php
session_start();

// if (empty($_SESSION['company_id'])) {
//     header("Location:../company_reg.php");
//     exit();
// }
require_once("../database.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($_SESSION['company_name']); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 20px;
        }
        .btn-custom {
            width: 100%;
            border-radius: 5px;
        }
        .btn-custom-primary {
            background-color: #007bff;
            color: #fff;
            border: none;
        }
        .btn-custom-primary:hover {
            background-color: #0056b3;
        }
        .btn-custom-warning {
            background-color: #ffc107;
            color: #212529;
            border: none;
        }
        .btn-custom-warning:hover {
            background-color: #e0a800;
        }
        .btn-custom-danger {
            background-color: #dc3545;
            color: #fff;
            border: none;
        }
        .btn-custom-danger:hover {
            background-color: #c82333;
        }
        .sidebar {
            background-color: #343a40;
            padding: 20px;
            color: #fff;
        }
        .main-content {
            padding: 20px;
        }
        h4 {
            margin: 20px 0;
            color: #343a40;
        }
        @media (max-width: 768px) {
            .sidebar {
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h4>Welcome Back, <?php echo htmlspecialchars($_SESSION['name']); ?></h4>
        <div class="row">
            <div class="col-md-4 sidebar">
                <div class="mb-3">
                    <a href="addproduct.php" class="btn btn-custom btn-custom-primary">Add Product</a>
                </div>
                <div class="mb-3">
                    <a href="manageproduct.php" class="btn btn-custom btn-custom-warning">Manage Product</a>
                </div>
                <div>
                    <a href="../logout.php" class="btn btn-custom btn-custom-danger">Logout</a>
                </div>
            </div>
            <div class="col-md-8 main-content bg-light">
                <!-- Main content goes here -->
            </div>
        </div>
    </div>
</body>
</html>
