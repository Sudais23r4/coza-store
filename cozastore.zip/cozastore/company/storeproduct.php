<?php
session_start();
// if (empty($_SESSION['company_id'])) {
//     header("Location:../company_reg.php");
//     exit();
// }
require_once("../database.php");

if (isset($_POST)) {
    
    //call data from previous page

    // $name=$_REQUEST['name'];

    $name=mysqli_real_escape_string($conn,$_POST['name']);
    $code=mysqli_real_escape_string($conn,$_POST['code']);
    $detail_one=mysqli_real_escape_string($conn,$_POST['detail_one']);
    $detail_three=mysqli_real_escape_string($conn,$_POST['detail_three']);
    $gender=mysqli_real_escape_string($conn,$_POST['gender']);
    $s_fabric=mysqli_real_escape_string($conn,$_POST['s_fabric']);
    $t_fabric=mysqli_real_escape_string($conn,$_POST['t_fabric']);
    $description=mysqli_real_escape_string($conn,$_POST['description']);
    $price=mysqli_real_escape_string($conn,$_POST['price']);
    $detail_two=mysqli_real_escape_string($conn,$_POST['detail_two']);
    $color=mysqli_real_escape_string($conn,$_POST['color']);


    // apply condition to make/check data unique

    $sql="SELECT name,code FROM clothes WHERE name='$name' OR code='$code'";
    $result=$conn->query($sql);

    // whatshappen if above condition true or false(0,1)
        // 1         ==   0
        // 0==0
    if ($result->num_rows == 0) {
        $uploadOk = true;
        $folder_dir = "../upload/product/";
        $base = basename($_FILES['image']['name']);
        $imageFileType = pathinfo($base, PATHINFO_EXTENSION);
        $file = uniqid() . "." . $imageFileType;
        $filename = $folder_dir . $file;
        if (file_exists($_FILES['image']['tmp_name'])) {
            if ($imageFileType == "png" || $imageFileType == "jpg") {
                if ($_FILES['image']['size'] <= 500000) { // Changed to 500KB for better error handling
                    if (move_uploaded_file($_FILES["image"]["tmp_name"], $filename)) {
                        // File uploaded successfully
                    } else {
                        $_SESSION['uploadError'] = "Failed to move uploaded file.";
                        $uploadOk = false;
                    }
                } else {
                    $_SESSION['uploadError'] = "File size too large. Maximum 500KB allowed.";
                    $uploadOk = false;
                }
            } else {
                $_SESSION['uploadError'] = "Invalid file format. Only JPG and PNG are allowed.";
                $uploadOk = false;
            }
        } else {
            $_SESSION['uploadError'] = "No file was uploaded.";
            $uploadOk = false;
        }

        if ($uploadOk == false) {
            header("Location: company_register.php");
            exit();
        }
        $sql="INSERT INTO clothes(company_id,name,code,price,description,detail_one,detail_two,detail_three,color,gender,shirt_fabric,trouser_fabric,logo)VALUES('{$_SESSION['company_id']}','$name','$code','$price','$description','$detail_one','$detail_two','$detail_three','$color','$gender','$s_fabric','$t_fabric','$file')";
        if ($conn->query($sql)===TRUE) {
            header("Location:../product.php");
            exit();
        }
        else{
            $_SESSION['registerError']=true;
            header("Location:addproduct.php");
            exit();
        }
    }
    else{
        echo "Data is already store in DB";
    }


}
else{
    echo "Error";
}

?>

