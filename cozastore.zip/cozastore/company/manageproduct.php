<?php
session_start();

// if (empty($_SESSION['company_id'])) {
//     header("Location: ../company_reg.php");
//     exit();
// }

require_once("../database.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        a { text-decoration: none!important; }
        .sidebar {
            background-color: #f8f9fa;
            padding: 20px;
            border-right: 1px solid #dee2e6;
            height: 100vh;
        }
        .sidebar a {
            display: block;
            margin-bottom: 10px;
        }
        .sidebar button {
            width: 100%;
        }
        .main-content {
            padding: 20px;
        }
        .table th, .table td {
            text-align: center;
        }
        .btn-custom {
            border-radius: 5px;
            width: 100%;
        }
        .btn-primary {
            background-color: #007bff;
            border: none;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .btn-warning {
            background-color: #ffc107;
            border: none;
        }
        .btn-warning:hover {
            background-color: #e0a800;
        }
        .btn-secondary {
            background-color: #6c757d;
            border: none;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        .btn-danger {
            background-color: #dc3545;
            border: none;
        }
        .btn-danger:hover {
            background-color: #c82333;
        }
        @media (max-width: 768px) {
            .sidebar {
                height: auto;
                border-right: none;
                border-bottom: 1px solid #dee2e6;
            }
            .main-content {
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-2 sidebar">
                <h4>Manage Product</h4>
                <a href="addproduct.php"><button type="button" class="btn btn-primary btn-custom">Add Product</button></a>
                <a href="manageproduct.php"><button type="button" class="btn btn-warning btn-custom">Manage Product</button></a>
                <!-- <a href="oppomobile.php"><button type="button" class="btn btn-secondary btn-custom">Oppo Mobile</button></a> -->
                <a href="../logout.php"><button type="button" class="btn btn-danger btn-custom">Logout</button></a>
            </nav>
            <main class="col-md-10 main-content">
                <h3 class="mb-4">Product List</h3>
                <div class="table-responsive">
                    <table class="table table-hover table-striped">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Price</th>
                                <th>Detail One</th>
                                <th>Detail Two</th>
                                <th>Color</th>
                                <th>Gender</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sql = "SELECT * FROM clothes WHERE company_id='$_SESSION[company_id]'";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                            ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['name']); ?></td>
                                <td><?php echo htmlspecialchars($row['price']); ?></td>
                                <td><?php echo htmlspecialchars($row['detail_one']); ?></td>
                                <td><?php echo htmlspecialchars($row['detail_two']); ?></td>
                                <td><?php echo htmlspecialchars($row['color']); ?></td>
                                <td><?php echo htmlspecialchars($row['gender']); ?></td>
                                <td><a href="delete.php?id=<?php echo $row['clothes_id']; ?>" class="btn btn-danger btn-sm">Delete</a></td>
                            </tr>
                            <?php
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>
</body>
</html>
