<?php
session_start();
require_once ("../database.php");
if (isset($_GET)) {
	

	$sql="DELETE FROM clothes WHERE clothes_id='$_GET[id]'";
	if ($conn->query($sql)===TRUE) {
		header("Location:manageproduct.php");
	}
}




?>