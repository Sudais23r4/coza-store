<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <style>
        body {
            background: linear-gradient(to right, #00c6ff, #0072ff);
            color: #fff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
        }
        .container {
            background: #ffffff;
            color: #333;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        h3 {
            color: #0072ff;
            border-bottom: 2px solid #0072ff;
            padding-bottom: 10px;
            margin-bottom: 20px;
            font-size: 24px;
        }
        .btn {
            transition: background-color 0.3s, color 0.3s;
        }
        .btn-primary {
            background-color: #0072ff;
            border: none;
        }
        .btn-primary:hover {
            background-color: #005bb5;
        }
        .btn-warning {
            background-color: #f39c12;
            border: none;
        }
        .btn-warning:hover {
            background-color: #e67e22;
        }
        .btn-danger {
            background-color: #e74c3c;
            border: none;
        }
        .btn-danger:hover {
            background-color: #c0392b;
        }
        .form-control {
            border-radius: 5px;
            border: 1px solid #ddd;
            box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
        }
        .form-control:focus {
            border-color: #0072ff;
            box-shadow: 0 0 0 0.2rem rgba(38, 143, 255, 0.25);
        }
        .card {
            background: #f9f9f9;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .card-header {
            background: #0072ff;
            color: #fff;
            border-bottom: 2px solid #005bb5;
            padding: 15px;
            border-radius: 10px 10px 0 0;
            font-size: 20px;
        }
        .card-body {
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h3 class="text-center">Add Product</h3>
        <div class="row">
            <div class="col-md-4 mb-3">
                <div class="card">
                    <div class="card-header">Add Product</div>
                    <div class="card-body">
                        <a href="addproduct.php" class="btn btn-primary w-100 mb-2">Add Product</a>
                        <a href="manageproduct.php" class="btn btn-warning w-100 mb-2">Manage Product</a>
                        <a href="../logout.php" class="btn btn-danger w-100">Logout</a>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <form action="storeproduct.php" method="POST" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <input type="text" class="form-control" placeholder="Product Name" name="name" required>
                            </div>
                            <div class="mb-3">
                                <input type="text" class="form-control" placeholder="Product Code" name="code" required>
                            </div>
                            <div class="mb-3">
                                <input type="text" class="form-control" placeholder="Detail One" name="detail_one" required>
                            </div>
                            <div class="mb-3">
                                <input type="text" class="form-control" placeholder="Detail Three" name="detail_three" required>
                            </div>
                            <div class="mb-3">
                                <input type="text" class="form-control" placeholder="Gender" name="gender" required>
                            </div>
                            <div class="mb-3">
                                <input type="text" class="form-control" placeholder="Shirt Fabric" name="s_fabric" required>
                            </div>
                            <button class="btn btn-primary w-100">Add Product</button>
                            <?php if (isset($_SESSION['registerError'])) { ?>
                                <div class="alert alert-danger mt-2" role="alert">
                                    Already Exists! Choose A Different!
                                </div>
                                <?php unset($_SESSION['registerError']); } ?> 
                            <?php if (isset($_SESSION['uploadError'])) { ?>
                                <div class="alert alert-danger mt-2" role="alert">
                                    <?php echo $_SESSION['uploadError']; ?>
                                </div>
                                <?php unset($_SESSION['uploadError']); } ?>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <input type="number" class="form-control" placeholder="Price" name="price" required>
                            </div>
                            <div class="mb-3">
                                <input type="text" class="form-control" placeholder="Description" name="description" required>
                            </div>
                            <div class="mb-3">
                                <input type="text" class="form-control" placeholder="Detail Two" name="detail_two" required>
                            </div>
                            <div class="mb-3">
                                <input type="text" class="form-control" placeholder="Color" name="color" required>
                            </div>
                            <div class="mb-3">
                                <input type="text" class="form-control" placeholder="Trouser Fabric" name="t_fabric" required>
                            </div>
                            <div class="mb-3">
                                <input class="form-control" type="file" name="image" required>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
