<?php
session_start();

// Check if the cart is empty, if not, create an empty cart array
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

// Handle Add to Cart
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['Add_to_Cart'])) {
    $product_id = $_POST['product_id'];
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $quantity = 1;

    // Check if the product is already in the cart
    $item_array_id = array_column($_SESSION['cart'], 'product_id');

    if (in_array($product_id, $item_array_id)) {
        // Product already in cart, increase the quantity
        foreach ($_SESSION['cart'] as $key => $value) {
            if ($value['product_id'] == $product_id) {
                $_SESSION['cart'][$key]['quantity'] += 1;
            }
        }
    } else {
        // Product not in cart, add it
        $item_array = array(
            'product_id' => $product_id,
            'product_name' => $product_name,
            'product_price' => $product_price,
            'quantity' => $quantity
        );

        $_SESSION['cart'][] = $item_array;
    }

    // Redirect to the cart page
    header("Location: shoping-cart.php");
    exit();
}

// Handle Remove from Cart
if (isset($_GET['action']) && $_GET['action'] == 'remove') {
    $product_id = $_GET['id'];

    foreach ($_SESSION['cart'] as $key => $value) {
        if ($value['product_id'] == $product_id) {
            unset($_SESSION['cart'][$key]);
            $_SESSION['cart'] = array_values($_SESSION['cart']); // Reindex the array
        }
    }

    // Redirect to the cart page
    header("Location: shoping-cart.php");
    exit();
}
?>
