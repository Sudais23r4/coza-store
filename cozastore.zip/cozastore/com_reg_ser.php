<?php
session_start();
require_once ("database.php");


if (isset($_POST)) {
	
	//call data from previous page

	// $name=$_REQUEST['name'];

	$name=mysqli_real_escape_string($conn,$_POST['name']);
	$email=mysqli_real_escape_string($conn,$_POST['email']);
	$password=mysqli_real_escape_string($conn,$_POST['password']);
	$cmp_name=mysqli_real_escape_string($conn,$_POST['cmp_name']);
	$country=mysqli_real_escape_string($conn,$_POST['country']);
	$city=mysqli_real_escape_string($conn,$_POST['city']);
	$type=mysqli_real_escape_string($conn,$_POST['type']);
	$contact=mysqli_real_escape_string($conn,$_POST['contact']);

	// apply condition to make/check data unique

	$sql="SELECT email,company_name FROM company WHERE email='$email' OR company_name='$cmp_name'";
	$result=$conn->query($sql);

	// whatshappen if above condition true or false(0,1)
		// 1         ==   0
		// 0==0
	if ($result->num_rows == 0) {
		$uploadOk = true;
		$folder_dir = "upload/logo/";
		$base = basename($_FILES['image']['name']);
		$imageFileType = pathinfo($base, PATHINFO_EXTENSION);
		$file = uniqid() . "." . $imageFileType;
		$filename = $folder_dir . $file;
		if (file_exists($_FILES['image']['tmp_name'])) {
			if ($imageFileType == "png" || $imageFileType == "jpg") {
				if ($_FILES['image']['size'] <= 500000) { // Changed to 500KB for better error handling
					if (move_uploaded_file($_FILES["image"]["tmp_name"], $filename)) {
						// File uploaded successfully
					} else {
						$_SESSION['uploadError'] = "Failed to move uploaded file.";
						$uploadOk = false;
					}
				} else {
					$_SESSION['uploadError'] = "File size too large. Maximum 500KB allowed.";
					$uploadOk = false;
				}
			} else {
				$_SESSION['uploadError'] = "Invalid file format. Only JPG and PNG are allowed.";
				$uploadOk = false;
			}
		} else {
			$_SESSION['uploadError'] = "No file was uploaded.";
			$uploadOk = false;
		}

		if ($uploadOk == false) {
			header("Location: company_register.php");
			exit();
		}
		$sql="INSERT INTO company(name,email,password,contact,country,city,company_name,company_type,logo)VALUES('$name','$email','$password','$contact','$country','$city','$cmp_name','$type','$file')";
		if ($conn->query($sql)===TRUE) {
			header("Location:company_login.php");
			exit();
		}
		else{
			$_SESSION['registerError']=true;
			header("Location:company_register.php");
			exit();
		}
	}
	else{
		echo "Data is already store in DB";
	}


}
else{
	echo "Error";
}

?>


<!-- $sql="INSERT INTO company(name,email,password,contact,country,city,company_name,company_type)VALUES('$name','$email','$password','$contact','$country','$city','$cmp_name','$type')";
		if ($conn->query($sql)===TRUE) {
			header("Location:company_login.php");
			exit();
		}
		else{
			echo "Error ! DATA not store in DB";
		} -->