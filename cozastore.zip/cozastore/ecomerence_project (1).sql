-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 22, 2024 at 03:42 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecomerence project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `email`, `password`) VALUES
(1, 'hussnain12@gmail.com', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `clothes`
--

CREATE TABLE `clothes` (
  `company_id` int(255) NOT NULL,
  `clothes_id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `price` int(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `detail_one` varchar(255) NOT NULL,
  `detail_two` varchar(255) NOT NULL,
  `detail_three` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `shirt_fabric` varchar(255) NOT NULL,
  `trouser_fabric` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `logo1` int(255) NOT NULL,
  `logo2` int(255) NOT NULL,
  `time_stamp` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `clothes`
--

INSERT INTO `clothes` (`company_id`, `clothes_id`, `name`, `code`, `price`, `description`, `detail_one`, `detail_two`, `detail_three`, `color`, `gender`, `shirt_fabric`, `trouser_fabric`, `logo`, `logo1`, `logo2`, `time_stamp`) VALUES
(7, 35, 'Axel Roman', 'Quaerat molestias el', 801, 'Nihil neque fugit a', 'Nostrum est minus in', 'Vel in fugiat lorem ', 'Quis illo repudianda', 'Minima tempore irur', 'Sed quaerat impedit', 'Aliquid eu in earum ', 'Rem maiores saepe es', '66c47ba714113.jpg', 0, 0, '2024-08-20 11:19:03.084854'),
(7, 36, 'Mari Kerr', 'Aut beatae consequat', 36, 'Libero impedit quib', 'Consequuntur archite', 'Quia adipisci et eni', 'Voluptatem Consequa', 'In cillum quia et it', 'Velit minus pariatu', 'Similique aut accusa', 'Necessitatibus saepe', '66c481603daad.jpg', 0, 0, '2024-08-20 11:43:28.255747'),
(7, 37, 'Heather Stafford', 'Ipsum labore ipsum ', 123, 'Excepteur ut natus q', 'Quasi quasi doloribu', 'Laboriosam nihil in', 'Accusantium unde sin', 'Ex dolor quasi adipi', 'Perferendis qui even', 'Incidunt dolores id', 'Voluptate ipsa qui ', '66c48191ae63b.jpg', 0, 0, '2024-08-20 11:44:17.715794'),
(7, 38, 'Cailin Greer', 'Ipsa deserunt illum', 749, 'Aliqua Dolore nihil', 'Architecto blanditii', 'Excepturi cupiditate', 'Ut ut quos aliquam r', 'Praesentium in at ut', 'A repellendus Quis ', 'Fuga Sunt fugiat r', 'Non deserunt iste in', '66c4819d38dd8.jpg', 0, 0, '2024-08-20 11:44:29.235689'),
(7, 39, 'Dale Whitney', 'In alias deserunt ni', 231, 'Ullamco quisquam rer', 'Lorem omnis ut in de', 'Ratione possimus om', 'Neque consequuntur q', 'Officiis ullam in re', 'Sed fugiat earum ull', 'Velit consectetur o', 'Voluptas laborum Oc', '66c481ab6b891.jpg', 0, 0, '2024-08-20 11:44:43.446846'),
(7, 40, 'Declan Pugh', 'Dignissimos laborum', 207, 'Dolore aliquid volup', 'Recusandae Aut adip', 'Praesentium consequa', 'Commodi obcaecati hi', 'Error veniam saepe ', 'Eum ex lorem consect', 'Aut quia optio quos', 'Necessitatibus aliqu', '66c482642dc4c.jpg', 0, 0, '2024-08-20 11:47:48.190517'),
(7, 41, 'Eve Whitley', 'Sequi qui eiusmod qu', 267, 'Repellendus Fuga O', 'Dicta laborum Volup', 'Provident eos autem', 'Est do aute volupta', 'Ex do iste ullam ut ', 'Quas ea sapiente dol', 'Impedit et cupidita', 'Voluptates cum conse', '66c4826ac84a7.jpg', 0, 0, '2024-08-20 11:47:54.823058'),
(7, 42, 'Frances Peck', 'Sit fugit quisquam', 326, 'Provident consequat', 'Expedita dolor disti', 'Tenetur tempora culp', 'Libero qui deserunt ', 'Asperiores corporis ', 'Odio qui iste exerci', 'Enim itaque quaerat ', 'Anim repudiandae cor', '66c48274b6924.jpg', 0, 0, '2024-08-20 11:48:04.748538'),
(7, 43, 'Victoria Harper', 'Fugiat accusantium ', 83, 'Quae aut dolores ea ', 'Quis voluptas ex vol', 'Officia possimus co', 'Rerum ea sint in qui', 'Magnam inventore obc', 'Inventore accusantiu', 'Voluptate beatae vol', 'Officia sint eligend', '66c4827fa7dbd.jpg', 0, 0, '2024-08-20 11:48:15.689030'),
(15, 46, 'Lewis Logan', 'Consequuntur asperna', 952, 'Fugiat in exercitati', 'Explicabo Veniam s', 'Labore dolor exceptu', 'Sed duis nobis dolor', 'Cumque est et ipsam ', 'Distinctio Quis ita', 'Magna aut esse qui i', 'Repudiandae ipsum s', '66c71036ec09c.jpg', 0, 0, '2024-08-22 10:17:26.977555');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `company_id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `company_type` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `time_stamp` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`company_id`, `name`, `email`, `password`, `contact`, `country`, `city`, `company_name`, `company_type`, `logo`, `time_stamp`) VALUES
(11, 'Yael Alexander', 'kuqowam@mailinator.com', 'as', '4', 'Corrupti velit recu', 'Et nobis earum perfe', 'Jared Watts', 'Saepe consectetur q', '66c484aea7a17.jpg', '2024-08-20 11:57:34.693049'),
(12, 'Austin Bond', 'soqecy@mailinator.com', 'Pa$$w0rd!', '32', 'Porro ut voluptas au', 'Consequatur Facilis', 'Hiroko Fernandez', 'Ipsum tempora est n', '66c709b34988f.jpg', '2024-08-22 09:49:39.303817'),
(13, 'Maite Marquez', 'nykapahoxa@mailinator.com', 'asd', '42', 'Voluptas vitae conse', 'Et similique laborum', 'Laura Terry', 'Iste occaecat eiusmo', '66c709d46e5a3.jpg', '2024-08-22 09:50:12.453597'),
(14, 'Basia Hodge', 'jemilulo@mailinator.com', 'Pa$$w0rd!', '73', 'Aliquip non quasi pr', 'Fugit labore in sun', 'Wyatt Gamble', 'Illum nostrud est ', '66c71004afe1a.jpg', '2024-08-22 10:16:36.721157'),
(15, 'Kiayada Gentry', 'temaj@mailinator.com', 'cv', '34', 'Animi dignissimos v', 'Voluptas est non im', 'Basil Conway', 'Nam ex qui velit et ', '66c7101cae5b2.jpg', '2024-08-22 10:17:00.714738');

-- --------------------------------------------------------

--
-- Table structure for table `cu`
--

CREATE TABLE `cu` (
  `cu-id` int(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cu`
--

INSERT INTO `cu` (`cu-id`, `email`, `password`) VALUES
(3, 'qyjoxom@mailinator.com', '$2y$10$VVeJjzcuxSitdbbevLzM/uJx39UUO9KHi5YhX7do8tM4PC0EisV4G'),
(4, 'kamaqiv@mailinator.com', '$2y$10$duSwo.7/NE5P.oz1ZiiSoerUmJj1HQgzOxvODWafcmBBybqbdIrf2');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `time_stamp` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `clothes`
--
ALTER TABLE `clothes`
  ADD PRIMARY KEY (`clothes_id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`company_id`);

--
-- Indexes for table `cu`
--
ALTER TABLE `cu`
  ADD PRIMARY KEY (`cu-id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `clothes`
--
ALTER TABLE `clothes`
  MODIFY `clothes_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `company_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `cu`
--
ALTER TABLE `cu`
  MODIFY `cu-id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(255) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
